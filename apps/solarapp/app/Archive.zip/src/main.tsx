import { AppRegistry } from 'react-native';
import App from './app/App';
import 'react-native-gesture-handler';

AppRegistry.registerComponent('Solarapp', () => App);
